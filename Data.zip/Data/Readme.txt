Length: 222
Features: LBP, HOG, GIST
Scores: 1-10 1-least safe 10-most safe